<!doctype html>
<html lang="en">
  <head>
    <script src="https://cdn.jsdelivr.net/gh/openlayers/openlayers.github.io@master/en/v6.1.1/build/ol.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/openlayers/openlayers.github.io@master/en/v6.1.1/css/ol.css" type="text/css">   
    <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/style.css">
    
    <title>OpenLayers example</title>
  </head>
  <body>
    <div class="center"><h2>My Map (Krzysztof Gajda)</h2></div>
    <div id="map" class="map tooltip"></div>
    <script type = 'text/javascript' src = "<?php echo base_url(); ?>js/index.js"></script>
    <div id="myModal" class="modal">
        <div class="modal-content">
        <form class="form-container">
          <div class="center"><h1>Coordinates</h1></div>
          <div class='container'>
              <div class='fieldName'><label><b>EPSG 3857 Longtitutde</b></label></div>
              <div class='data'><div id="long_3857"></div></div>
          </div>
          <div class='container'>
            <div class='fieldName'><label><b>EPSG 3857 Latitutde</b></label></div>
            <div class='data'><div id="lat_3857"></div></div>
          </div>
            <br>
          <div class='container'>
            <div class='fieldName'><label><b>EPSG 4326 Longitutde</b></label></div>
            <div class='data'><div id="long_4326"></div></div>
          </div>
          <div class='container'>
            <div class='fieldName'><label><b>EPSG 4326 Latitutde</b></label></div>
            <div class='data'><div id="lat_4326"></div></div>
          </div>
          <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
        </form>
        </div>
    </div>
  </body>
</html>
</html>
