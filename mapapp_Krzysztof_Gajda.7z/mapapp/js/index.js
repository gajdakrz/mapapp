const localmap = new ol.Map({
        layers: [
            new ol.layer.Tile({
                source: new ol.source.OSM()
            })
        ],
        source: vectorSource,
        target: 'map',
        view: new ol.View({
            center: ol.proj.fromLonLat([30.41, 48.82]),
            zoom: 4
        })
});


var vectorSource = new ol.source.Vector({
});
var vectorLayer = new ol.layer.Vector({
    source: vectorSource
});
localmap.addLayer(vectorLayer);

localmap.on('singleclick', function (evt) {
    //longtitude 3857
    $("div#long_3857").text('');
    $("div#long_3857").text(evt.coordinate[0]);
    
    //latitude 3857
    $("div#lat_3857").text('');
    $("div#lat_3857").text(evt.coordinate[1]);
    
    // convert coordinate to EPSG-4326
    coordinate_4326 = ol.proj.transform(evt.coordinate, 'EPSG:3857', 'EPSG:4326');

    //longtitude 4326
    $("div#long_4326").text('');
    $("div#long_4326").text(coordinate_4326[0]);
    
    //latitude 4326
    $("div#lat_4326").text('');
    $("div#lat_4326").text(coordinate_4326[1]);
    
    //document.getElementById("myForm").style.display = "block";
    var modal = document.getElementById("myModal");
    modal.style.display = "block";
});

function closeForm() {
  //document.getElementById("myForm").style.display = "none";
  var modal = document.getElementById("myModal");
  modal.style.display = "none";
}